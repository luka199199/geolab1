$(document).ready(function() {



	$("#log-in").on("click", function(){
		$("#popup-container").fadeIn(500);
	});
	$("#close-button").on("click", function(){
		$("#popup-container").fadeOut(500);
	});


	$("#enter").on("click", function(){
		var username = $("#username").val();
		var password = $("#password").val();
		// console.log("test");
		// console.log(username);
		if(username == ""){
			var userError = "usenename requeired"
			$(".error").append("<span class='error-message'>" + userError + "</span>");
			// userError = "";
		}else if(password == ""){
			$(".error-message").remove();
			// userError = "";
			var userError = "password requeired"
			$(".error").append("<span class='error-message'>" + userError + "</span>");
		}else{
			// userError = "";
			$(".error-message").remove();
			var userError = "sucess"
			$(".error").append("<span class='sucess'>" + userError + "</span>");
		}
	});


});